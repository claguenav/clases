/**
 * 
 */
package UT2;

/**
 * 
 */
public class GuerreroClara_Reto1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// constantes
		final String APPNAME = "Ticket Farmacia"; // final string porque es una constante
		final float VERSION = 1.0f; // final float porque es una constante con caracteres decimales

		// variables

		String producto = "Ibuprofeno"; // string porque lleva letras
		byte cantidadCompra = 3; // byte al ser un caracter numerico pequeño

		float unitPrice = 19.99f; // float al tener decimales - no recuerdo la otra forma de ponerlo

		char categoria = 'A'; // char al tener un solo caracter
		boolean esPremium = true; // boolean porque es una variable de Si/No

		long id = 2_000_023_999; // long al ser un numero mas grande
 
		byte codigoAlmacen = 12; // byte porque solo necesita 2 bytes para ser almacenado
		short calificacion = 9; // 

		// dinero - todo con float al ser decimales

		float iva = 0.21f;
		float subtotal = 0f;
		float descuento = 0.10f;
		float ivaSubtotal = 0f;
		float total = 0f;

		subtotal = cantidadCompra * unitPrice;

		descuento = subtotal * descuento;

		subtotal -= descuento;

		ivaSubtotal = subtotal * iva;

		total = subtotal + ivaSubtotal;

		System.out.println("=== " + APPNAME + " v" + VERSION + " ===");
		System.out.println("Producto: " + producto + " (cat " + categoria + ")");
		System.out.println("Unidades: " + cantidadCompra);
		System.out.println("Calificación Producto: " + calificacion);
		System.out.println("Descuento: " + descuento + " €");
		System.out.println("Subtotal: " + subtotal + " €");
		System.out.println("IVA (21%): " + iva + " €");
		System.out.println("TOTAL: " + total +  " €");
		System.out.println("ID Ticket: " + id);
		System.out.println("Cliente premium: " + esPremium);
		System.out.println("Código Almacén: " + codigoAlmacen);

	}

}
